"""Per-clip colour grade for Sony S-Log3 / S-Gamut3.Cine footage.

Follows the texnika-davinci-color-grade node order, baked into one 3D LUT per clip:
  CST IN (S-Log3 -> scene linear, S-Gamut3.Cine)
  -> EXP (linear gain, like HDR Global)
  -> WB  (linear RGB gains from neutral pixels: white walls / white shirt)
  -> gamut S-Gamut3.Cine -> Rec.709 + filmic tone map (highlight roll-off, like DWG -> 709 CST OUT)
  -> CON (contrast around pivot 0.435)
  -> HSV SAT (gamma on S channel = lifts low-sat areas first, then small gain)
  -> LOOK at 50 % ("LUT key output 0.5"): warm highlights / slightly cool shadows, reds held
Vignette is added afterwards in ffmpeg (parallel-node power window equivalent).

usage:
  grade.py measure RAW.rgb48 W H            -> prints suggested exp / wb as JSON
  grade.py cube OUT.cube '{"exp":1.0,"wb":[r,g,b],...}'
"""
import json
import sys

import numpy as np

# ---------- CST IN ----------
def slog3_to_lin(x):
    x = np.asarray(x, dtype=np.float64)
    cv = x * 1023.0
    hi = (10.0 ** ((cv - 420.0) / 261.5)) * (0.18 + 0.01) - 0.01
    lo = (cv - 95.0) * 0.01125000 / (171.2102946929 - 95.0)
    return np.where(cv >= 171.2102946929, hi, lo)


def rgb_to_xyz(prim, white):
    xy = np.array(prim)
    XYZ = np.stack([xy[:, 0] / xy[:, 1], np.ones(3), (1 - xy[:, 0] - xy[:, 1]) / xy[:, 1]], 1).T
    W = np.array([white[0] / white[1], 1.0, (1 - white[0] - white[1]) / white[1]])
    S = np.linalg.solve(XYZ, W)
    return XYZ * S


D65 = (0.3127, 0.3290)
SG3C = rgb_to_xyz([(0.766, 0.275), (0.225, 0.800), (0.089, -0.087)], D65)
R709 = rgb_to_xyz([(0.64, 0.33), (0.30, 0.60), (0.15, 0.06)], D65)
M_SG3C_709 = np.linalg.inv(R709) @ SG3C
LUM709 = np.array([0.2126, 0.7152, 0.0722])


# ---------- CST OUT tone map ----------
def filmic(x):
    # ACES-fitted curve (Narkowicz), per channel, soft shoulder; 0.6 pre-scale.
    x = np.maximum(x, 0) * 0.6
    a, b, c, d, e = 2.51, 0.03, 2.43, 0.59, 0.14
    return np.clip((x * (a * x + b)) / (x * (c * x + d) + e), 0, 1)


def oetf(lin):  # display encode, BT.1886 inverse (gamma 2.4)
    return np.clip(lin, 0, 1) ** (1 / 2.4)


def rgb_to_hsv(rgb):
    mx = rgb.max(-1); mn = rgb.min(-1); d = mx - mn
    s = np.where(mx > 1e-6, d / np.maximum(mx, 1e-6), 0)
    return mx, s


def grade(slog, p):
    lin = slog3_to_lin(slog)                       # CST IN
    lin = lin * p.get("exp", 1.0)                  # EXP
    lin = lin * np.array(p.get("wb", [1, 1, 1]))   # WB
    lin = lin @ M_SG3C_709.T                       # gamut
    disp = oetf(filmic(lin))                       # CST OUT (tone map + gamma)
    # CON around pivot
    con, piv = p.get("con", 1.06), p.get("pivot", 0.435)
    disp = np.clip(piv + (disp - piv) * con, 0, 1)
    # HSV SAT: S' = S ** g (g<1 lifts low saturation), then gain
    v, s = rgb_to_hsv(disp)
    g, gain = p.get("sat_gamma", 0.88), p.get("sat_gain", 1.03)
    s2 = np.clip((s ** g) * gain, 0, 1)
    ratio = np.where(s > 1e-5, s2 / np.maximum(s, 1e-5), 1.0)
    disp = v[..., None] - (v[..., None] - disp) * ratio[..., None]
    disp = np.clip(disp, 0, 1)
    # LOOK at key output 0.5
    look = disp.copy()
    y = disp @ LUM709
    hi = np.clip((y - 0.45) / 0.55, 0, 1)[..., None]
    lo = np.clip((0.40 - y) / 0.40, 0, 1)[..., None]
    look = look + hi * np.array([0.022, 0.008, -0.020]) + lo * np.array([-0.012, 0.004, 0.016])
    # keep reds rich but not neon: slight pull of R where R dominates strongly
    rdom = np.clip((disp[..., 0] - np.maximum(disp[..., 1], disp[..., 2])) - 0.35, 0, 1)[..., None]
    look = look - rdom * np.array([0.10, 0.0, 0.0])
    # soft film black lift (very small)
    look = 0.012 + look * (1 - 0.012)
    mix = p.get("look_mix", 0.5)
    out = disp * (1 - mix) + np.clip(look, 0, 1) * mix
    return np.clip(out, 0, 1)


def measure(raw, w, h):
    a = np.fromfile(raw, dtype="<u2").reshape(h, w, 3).astype(np.float64) / 65535.0
    lin = slog3_to_lin(a)
    y = lin @ np.array([0.25, 0.65, 0.10])
    # neutral candidates: bright-ish, not clipped, low chroma
    chroma = (lin.max(-1) - lin.min(-1)) / np.maximum(lin.max(-1), 1e-4)
    m = (y > np.percentile(y, 55)) & (y < np.percentile(y, 97)) & (chroma < np.percentile(chroma, 25))
    n = lin[m].mean(0)
    wb = n[1] / n
    wb = np.clip(wb, 0.85, 1.18)
    # exposure: put the median scene luminance near 0.20 linear (high-key white interiors)
    med = np.median(y)
    exp = float(np.clip(0.20 / max(med, 1e-4), 0.6, 2.2))
    stats = dict(min_code=float(a.min()), p1=float(np.percentile(a, 1)), median_code=float(np.median(a)),
                 p99=float(np.percentile(a, 99)), neutral_px=int(m.sum()))
    return dict(exp=round(exp, 3), wb=[round(float(v), 3) for v in wb], stats=stats)


def write_cube(path, p, n=65):
    r = np.linspace(0, 1, n)
    b, g, rr = np.meshgrid(r, r, r, indexing="ij")  # cube order: R fastest
    grid = np.stack([rr, g, b], -1).reshape(-1, 3)
    out = grade(grid, p)
    with open(path, "w") as f:
        f.write(f"TITLE \"SLog3 grade {json.dumps(p)}\"\nLUT_3D_SIZE {n}\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 1 1 1\n")
        np.savetxt(f, out, fmt="%.6f")


if __name__ == "__main__":
    if sys.argv[1] == "measure":
        print(json.dumps(measure(sys.argv[2], int(sys.argv[3]), int(sys.argv[4]))))
    elif sys.argv[1] == "cube":
        write_cube(sys.argv[2], json.loads(sys.argv[3]))
