"""Per-shot full grade as one .cube (S-Log3 code in -> Rec.709 out): v5 per-channel gain + knee, then the common skin LUT."""
import sys, json, numpy as np
sys.path.insert(0, "/Users/meyor/Desktop/reels copy edit/_work/scripts"); from pre_v5 import pre
R = "/Users/meyor/Desktop/reels copy edit"
def load_cube(p):
    L = [l.split() for l in open(p) if l.strip() and l.strip()[0] in "0123456789.-"]
    n = int([l for l in open(p) if l.startswith("LUT_3D_SIZE")][0].split()[1])
    return np.array(L, float).reshape(n, n, n, 3), n   # [b][g][r]
def apply(lut, n, rgb):
    x = np.clip(rgb, 0, 1) * (n - 1); i0 = np.floor(x).astype(int).clip(0, n - 2); f = x - i0
    out = 0
    for dr in (0, 1):
        for dg in (0, 1):
            for db in (0, 1):
                w = (f[..., 0] if dr else 1 - f[..., 0]) * (f[..., 1] if dg else 1 - f[..., 1]) * (f[..., 2] if db else 1 - f[..., 2])
                out = out + w[..., None] * lut[i0[..., 2] + db, i0[..., 1] + dg, i0[..., 0] + dr]
    return out
shot, outp = sys.argv[1], sys.argv[2]
g = json.load(open(f"{R}/_work/meas/gain_v5.json"))[shot]
lut, n = load_cube(f"{R}/LUTs_AE/SATashkent_SKIN_common.cube"); N = 33
v = np.linspace(0, 1, N); b, gg, r = np.meshgrid(v, v, v, indexing="ij")
x = np.stack([pre(r, g[0]), pre(gg, g[1]), pre(b, g[2])], -1)
y = apply(lut, n, x).reshape(-1, 3)
with open(outp, "w") as f:
    f.write(f"LUT_3D_SIZE {N}\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 1 1 1\n")
    for p in y: f.write(f"{p[0]:.6f} {p[1]:.6f} {p[2]:.6f}\n")
