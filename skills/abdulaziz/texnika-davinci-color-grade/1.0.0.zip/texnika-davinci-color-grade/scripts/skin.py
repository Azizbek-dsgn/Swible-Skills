import json, sys, numpy as np
sys.path.insert(0,'_work/scripts'); import grade as G
P=json.load(open('_work/meas/params.json'))
FACES=['02','04','06','08','03']
def skin_stats(o):
    r,g,b=o[...,0],o[...,1],o[...,2]; mx=o.max(-1); mn=o.min(-1); s=(mx-mn)/np.maximum(mx,1e-4)
    m=(r>g)&(g>b)&(s>0.15)&(s<0.6)&(mx>0.25)&((r-g)/(np.maximum(mx-mn,1e-4))<0.9)
    y=o@np.array([.2126,.7152,.0722])
    return float(np.median(y[m])) if m.sum()>200 else float('nan'), float(np.percentile(y,95)-np.percentile(y,5)), float(s.mean())
def run(tag, mod):
    out=[]
    for k in FACES:
        a=np.fromfile(f'_work/meas/{k}.rgb48',dtype='<u2').reshape(480,270,3)/65535.0
        p=dict(P[k]); p.update(mod(p)); out.append(skin_stats(G.grade(a,p)))
    o=np.array(out); print(f"{tag:28s} skinY {np.nanmean(o[:,0]):.3f}  contrast {o[:,1].mean():.3f}  sat {o[:,2].mean():.3f}   per-shot skinY {np.round(o[:,0],2)}")
run("hozirgi (ref-match)", lambda p:{})
run("ref-match oldingi (neytral)", lambda p:dict(exp=p['exp']/0.78, con=1.10, sat_gamma=0.9, sat_gain=1.0, look_mix=0.5))
for m in (1.0,1.12,1.25):
    for con in (0.95,1.0):
        run(f"exp x{m/0.78:.2f} con {con} sat.9/1.05", lambda p,m=m,con=con:dict(exp=p['exp']/0.78*m, con=con, sat_gamma=0.9, sat_gain=1.05, look_mix=0.5))
