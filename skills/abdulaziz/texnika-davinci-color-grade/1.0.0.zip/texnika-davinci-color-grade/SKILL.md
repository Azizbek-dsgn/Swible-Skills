---
name: texnika-davinci-color-grade
description: >-
  ALWAYS apply automatically, without being asked, whenever footage must be colour-corrected or graded, in DaVinci Resolve or any other tool (the same order and checks carry over to Lumetri/ffmpeg), unless the footage is an already-graded master. Technique: Declan Jenkinson's "exact system" — DaVinci Wide Gamut colour management, CST IN/OUT for log, fixed node order EXP → WB → CON → HSV SAT, scopes, LUT at reduced key output, parallel power windows, power grades, shot matching. Triggers: "color grade", "rang to'g'irlash", "davinci", "grade qil", "log footage", "slog3", "teri rangi", "shotlarni moslash". A technique, not a motion style; do not mix into stil-* skills. Includes the user's overriding rules: never re-grade a graded master unless asked; skin first (face luma ~0.52, contrast ≤1.0, no orange skin, no clipped highlights); vertical S-Log3; ffmpeg/AE LUT pipelines with scripts.
---

# DaVinci Resolve'da rang tizimi (YT07 · Declan Jenkinson "The EXACT SYSTEM To Colour Grade Anything")

Manba: https://youtu.be/3g8TA5n92Bs — 39:46 dars, DaVinci Resolve Studio 20.
Fayl: `~/Desktop/reference editor/YT_refs/YT07_3g8TA5n92Bs.mp4`. Transkript: `references/transkript.txt`. Kadrlar: `references/kadrlar/` (kamera CST jadvali, node daraxti).

Belgilar: **[D]** darsda aytilgan · **[K]** kadrda ko'rildi · **[T]** taxmin.

**Correction va grading farqi** [D]: correction = ekspozitsiya, oq balans, kontrast va to'yinganlikni to'g'rilash. Grading = LUT, maskalar va yorug'likni shakllantirish bilan ijodiy ko'rinish berish.

## 0. Loyiha sozlamalari (bir marta) [D]
Pastki o'ngdagi tishli g'ildirak → Color Management:
| Sozlama | Qiymat |
|---|---|
| Color science | **DaVinci YRGB** |
| Timeline color space | **DaVinci Wide Gamut Intermediate** (default Rec.709 Scene emas) |
| Output — Windows, internet | Rec.709 Gamma **2.2** |
| Output — Windows, kino/TV | Rec.709 Gamma **2.4** |
| Output — Mac | **Rec.709-A** (Mac gamma siljishi muammosi) |
- ⋯ → "Set current settings as default preset" → Update (keyingi loyihalarda qayta sozlanmaydi).
- **Mac**: Preferences → System → General → **Use Mac display color profiles for viewers** yoqilsin, Save.
- Nega Wide Gamut: Rec.709 kichik rang fazosi. Unda ekspozitsiyani ko'tarsangiz yorug' joylar tez kesiladi, DWG da shu ma'lumot saqlanadi (darsda ko'rsatilgan).

## 1. Node daraxti [D][K] (`kadrlar/node_daraxti.jpg`)
```
CST IN → EXP → WB → CON → HSV SAT → [parallel: MASK, MASK…] → CST OUT → LUT
```
- Node qo'shish: **Option+S** (Mac) / **Alt+S** (Win); nom: **R**; o'chirib-yoqish (oldin/keyin): **D**. Right-click → Clean Up Node Graph.
- Correction node'lari CST IN va CST OUT orasida, ya'ni keng DWG fazosida ishlaydi. LUT esa CST OUT dan keyin.

## 2. Log → CST [D] (faqat log'da suratga olinganda; oddiy profil bo'lsa bu qadam tashlab ketiladi)
Effects → **Color Space Transform** ni CST IN va CST OUT node'lariga.
- **CST IN**: Input = kamera (jadval pastda) → Output color space **DaVinci Wide Gamut**, Output gamma **DaVinci Intermediate**.
- **CST OUT**: Input DaVinci Wide Gamut / DaVinci Intermediate → Output **Rec.709**, gamma 2.2 / 2.4 (Win) yoki Rec.709-A (Mac).

| Brend | Log | Input Color Space | Input Gamma |
|---|---|---|---|
| Sony | S-Log3 | Sony S-Gamut3.Cine | S-Log3 |
| Canon | Canon Log 2 | Canon Cinema Gamut | Canon Log 2 |
| Canon | Canon Log 3 | Canon Cinema Gamut | Canon Log 3 |
| DJI | D-Log | DJI D-Gamut | D-Log |
| Panasonic Lumix | V-Log | Panasonic V-Gamut | V-Log |

## 3. Correction — 4 qadam
### EXP (ekspozitsiya) [D]
- Asbob: **HDR Wheels → Global** (kameradagi ISO kabi ishlaydi; Offset emas).
- Waveform sozlash: Waveform rejimi (Parade emas), sozlamada **Y**, Colorize **o'chiq**; ⋯ → Display Qualifier Focus yoqiq, scale **percentage** (0–100).
- Qoida: ma'lumot **0 va 100 orasida**. 100 dan yuqori = kesilish (clipping), 0 ga yopishgan = soyalar "ezilgan" (crush). Waveform tepasidagi tekis chiziq ham kesilish belgisi.
- **Kontekst muhim**: tungi sahna pastda bo'lishi, quyoshga qarshi kadrda osmon kesilishi normal.
- Nozik sozlash: Primaries → Lift / Gamma / Gain (≈ soyalar / o'rta / yorug'lar), alohida **Highlights** slayderi faqat eng yorug' joyga.
- Ekspozitsiyani postda ko'tarishdan iloji boricha qoching (shovqin chiqadi); kerak bo'lsa ko'tarib, Highlights/Gain bilan yorug'larni ushlab qoling.

### WB (oq balans) [D] — ikki usul
1. **Neytral joy** (qora/kulrang/oq: qora kapyushon, oq mashina, oq ko'ylak): waveform → **RGB + Colorize**, qualifier bilan neytral joy ustida turib, R/G/B chiziqlarini Primaries'da tenglashtiring (masalan ko'kni kamaytirib, yashilni qo'shib).
2. **Teri** (teri bor bo'lsa — eng yaxshi tayanch): **Vectorscope**, sozlamada **2× zoom** va **Skin Tone Indicator** yoqiq; qualifier bilan teri ustida turib, nuqta **skin tone chizig'ining markazida** bo'lsin. Avval ozroq saturation qo'shsangiz o'qish osonlashadi.
- Keyingi qadamlardan keyin (LUT, saturation) WB'ga qaytib qayta to'g'rilash — normal.

### CON (kontrast) [D]
- Primaries → **Contrast** o'ngga → **Pivot** chapga suriladi (kontrastni "ochadi": qaysi qism ko'proq ta'sirlanishini o'zgartiradi). Kadrda kontrast 1.000, pivot 0.435 [K].

### HSV SAT (to'yinganlik) [D]
- Oddiy Saturation tez "zaharli" bo'ladi (ayniqsa teri va yorqin ranglarda).
- Node → right-click → Color Space → **HSV**; Channels → **1-kanal va 3-kanalni o'chiring** (faqat S kanal qoladi).
- **Gamma** ↑ — asosan kam to'yingan joylarni to'yintiradi (yumshoq, kinematografik). **Gain** ↑ — global. Ikkalasini birga ishlatib, muvozanat topiladi.

## 4. Grading [D]
### LUT
- CST OUT dan keyin "LUT" node. LUT papkasi: LUTs → istalgan papka → Reveal in Finder → .cube faylni tashlang → Refresh → node'ga torting.
- LUT ataylab kuchli qilingan → node **Key Output = 0.5** dan boshlab kamaytiring.
- **Kamroq — ko'proq.** "LUT tashlab qo'yilgani" sezilsa — qimmat ko'rinmaydi.

### Power Windows (yorug'likni shakllantirish)
- Har maska — **parallel node**da (node → right-click → Add Parallel). Hammasi CST OUT gacha bo'lgan bitta "toza" tasvirdan oladi va teng aralashtiriladi. Ketma-ket qo'yilganda maskalar bir-biri bilan "urishadi".
- **Vinyetka**: aylana window → kattalashtirib, tashqi chiziq bilan feather → **invert** → Primaries **Gamma ↓**.
- **Subyektni yoritish**: kichik aylana subyekt ustida, katta feather → ozgina **Gain ↑**.
- **Chalg'ituvchi yorug' joy**: gradient window → Gamma yoki Highlights ↓.
- **Ko'zni qamashtiruvchi yaltiroq (glare)**: alohida window → Highlights ↓.
- Window'larni kadrdagi **tabiiy yorug'lik chiziqlari bo'ylab** qo'ying (masalan derazadan tushgan yorug'lik chegarasi) — shunda realistik ko'rinadi.
- Harakatlanuvchi kadrda: Tracker → oldinga/orqaga track — maska subyektga yopishadi.

## 5. Tezlashtirish [D]
- **Power Grade**: tayyor node daraxti shabloni (nomlangan node'lar + CST sozlangan). Gallery → Power Grades → right-click Import; klipda right-click → **Apply Grade**. Kamera bo'yicha alohida variant (Sony / Lumix / DJI / Canon).
- Grade nusxalash: **Cmd+C / Cmd+V** (Win: Ctrl).

## 6. Shotlarni moslash [D]
1. Namuna klipda Gallery → Stills → right-click **Grab Still**.
2. Ikkinchi klipda split-screen (wipe) ikonkasini yoqing; chegarani suring — waveform'da ham bo'linish ko'rinadi.
3. Ikkala kadrdagi **umumiy obyekt**ni (masalan bir xil beton) tayanch qilib, EXP Global bilan ekspozitsiyani tenglang.
4. WB'ni vectorscope'dagi teri nuqtasi bo'yicha moslang; qaysi ko'rinish yoqsa, ikkinchisini unga tortasiz.
5. Muqobil: Viewer'da ikki kadrni yonma-yon ko'rish.

## Ish tartibi (har klip)
1. Power Grade qo'llash (yoki node daraxtini qo'lda qurish).
2. EXP (waveform Y) → WB (RGB colorize yoki vectorscope) → CON (+pivot) → HSV SAT (gamma, keyin gain).
3. LUT, key output ~0.5.
4. Parallel maskalar: vinyetka → subyekt → chalg'ituvchilar; kerak bo'lsa track.
5. D bilan oldin/keyin; WB'ga qaytib qayta tekshirish.
6. Sahnadagi boshqa kliplarni still + split-screen bilan moslash.

## Foydalanuvchi qoidalari (bu darsdan ustun)
1. **Tayyor graded master'ga tegilmaydi.** Bu skill faqat log/grade qilinmagan materialda yoki foydalanuvchi rang so'raganda (Xitoy, 2026-11-07: o'sha video uchun per-channel Levels — oq ko'ylak neytral, teri iliqroq).
2. **Teri birinchi** [F, 2026-11-14: "kontrast juda ko'payib ketgan va odam terisiyam qorayib ketgan"]:
   - EXP oq devor yoki sahna median'i bo'yicha emas, **yuz bo'yicha**: yuz luma ≈ 0.50–0.55 (derazaga qarshi kadr ~0.40), teri RGB ≈ 160–170 / 120–130 / 100. Yuz `scripts/faces.swift` (macOS Vision) bilan topiladi; yuzsiz kadrlar qo'shnisiga moslanadi (median ~0.56).
   - CON ≤ 1.0 (pivot 0.435), HSV SAT gain ≤ 1.0 (gamma 0.9), look/LUT aralashmasi ≤ 35%.
   - Iliq "look" terini to'q sariq qilmasin. Reference'ga moslash ("ref-match": kontrast 1.14, sat 1.12) terini qoraytirgan — rad etilgan.
3. **Yorug'lar kuymasin** [F, 2026-11-14: "kadrlar yonib ketibdi"]: S-Log3 kodida ~+2 stopdan yuqorisi yumshoq siqiladi; 0.95 dan yorug' piksel 0%, p95 0.69–0.84.
4. **Vertikal S-Log3** (Sony, 90° matritsa): avto-aylantirilgan 2160×3840 — landshaft deb kesmang. Fayllar full-range (qora ~109 kod).
5. **Pipeline variantlari (DaVinci'siz):**
   - **ffmpeg / Python:** `scripts/grade.py` — CST IN (S-Log3 → chiziqli, S-Gamut3.Cine) → EXP gain → WB (neytral piksellar bo'yicha) → CST OUT (Rec.709 + filmic roll-off) → CON → HSV SAT → look → vinyetka; `scripts/mkcube.py` bilan har klipga 65³ `.cube`. `scripts/skin.py` — variantlarni teri yorqinligi/kontrast/sat bo'yicha solishtiradi.
   - **After Effects:** har klipda `Levels (Individual Controls)` (S-Log3 domenida EXP + WB + yorug' siqish) + umumiy GRADE adjustment: `Apply Color LUT` (umumiy teri LUT) + CC Vignette 28. Aniq per-klip LUT bilan farq 0.07–0.38/255.
   - **Sony LC-709** LUT + EXP → WB → CON → SAT, bitta `.cube` ga yig'ib qo'llash (C2776) — tez va filtr zanjiri bilan bir xil.
6. **Grafika** grade qatlamidan yuqorida (LUT matnga ta'sir qilmaydi). AI kadrlar ham yuqorida — ular allaqachon Rec.709.
7. **QA:** oldin/keyin varag'i (`references/kadrlar/foydalanuvchi_teri_v4.jpg` — ma'qullangan natija), har shotda yuz luma va kesilgan piksel %.
